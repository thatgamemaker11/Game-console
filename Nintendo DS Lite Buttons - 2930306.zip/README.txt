Nintendo DS Lite Buttons by jusbot on Thingiverse: https://www.thingiverse.com/thing:2930306

Summary:
Building a mintyPi 2.0 and I needed some nintendo DS lite buttons.WIP - I intend to print this on a Formlabs Form 2, but haven't been able to yet. Also going to try to print on an FDM machine, but I'm not hopeful... Added .f3d files